/*
 *
 * Steroids Common Runtime
 *
 */

(function(){

    function CommonRuntime() {

        var self = this;

        self.start = function(){
            console.log('starting CommonRuntime !!!');

            //polifill for steroids object that does not exists i the CommonRuntime
            GLOBAL.steroids = GLOBAL.steroids || {};
            GLOBAL.steroids.fireSteroidsEvent = function(){
                console.log('mock steroids.fireSteroidsEvent function');
            };
            GLOBAL.steroids.on = function(){};

        };

        self.notify = function(notification){
            //notify of system events, app went to background/foreground.
            console.log('CommonRuntime notify ... notification: ' + JSON.stringify(notification));
        };

        /**
         * command is:
            module -> the target node module. -> i.e. steroidsData
            func -> function to be called in the module object.
            (Callback functions:)
            successCallbacks
            failureCallbacks
            recurringCallbacks
         */
        self.execute = function(command){
            //execute a command ... used for steroids data for example
            console.log('CommonRuntime execute -> command: ' + JSON.stringify(command));

            var obj = require(command.parameters.module),
                func = command.parameters.func;

            obj[func].apply(obj, [command]);
        };

        self.stop = function(){
            //we save the state here before this common runtime is shutdown..
            //it can be shutdown because of app restarts (scanner) or real shutdown :-)
            console.log('CommonRuntime stoping ...');

        };
    }

    var commonRuntime = new CommonRuntime();

    //expose the instance
    module.exports = commonRuntime;

})();




